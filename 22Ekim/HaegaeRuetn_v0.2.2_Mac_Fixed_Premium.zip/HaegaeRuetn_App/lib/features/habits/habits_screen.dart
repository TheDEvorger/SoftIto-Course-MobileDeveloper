import 'package:flutter/material.dart';

import '../../core/models/habit.dart';
import '../../core/state/realm_controller.dart';
import '../../core/widgets/original_kingdom_art.dart';
import '../../core/widgets/ornate_widgets.dart';
import '../../core/widgets/realm_card.dart';
import 'habit_editor_sheet.dart';

class HabitsScreen extends StatelessWidget {
  const HabitsScreen({super.key, required this.controller});

  final RealmController controller;

  void openEditor(BuildContext context, [Habit? habit]) => showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        backgroundColor: const Color(0xFFF8F3E8),
        builder: (context) => HabitEditorSheet(controller: controller, habit: habit),
      );

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final era = c.era;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      children: [
        FancyHeroHeader(
          title: 'Bugünkü Vazifeler',
          subtitle: '${era.name} Çağı • ${c.rank} • “Küçük adımlar büyük krallıklar kurar.”',
          assetPath: ArtAssets.habits,
          badge: FramedIconBadge(
            icon: Icons.workspace_premium_outlined,
            label: 'İtibar',
            value: '${c.reputation}/100',
            color: era.primary,
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: MiniStatCard(
                label: 'TECRÜBE',
                value: '${c.xp} XP',
                icon: Icons.auto_awesome,
                color: era.secondary,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: MiniStatCard(
                label: 'TAMAM',
                value: '${c.todayCompleted}/${c.activeHabits.length}',
                icon: Icons.task_alt,
                color: const Color(0xFFFFE6B9),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: MiniStatCard(
                label: 'ROZET',
                value: '${c.badgeCount}/24',
                icon: Icons.emoji_events_outlined,
                color: const Color(0xFFE9DDFC),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        RealmCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text('Bugünkü seferin', style: Theme.of(context).textTheme.titleLarge),
                  ),
                  RealmPill(label: '%${c.todayPercent} tamamlandı', color: era.secondary),
                ],
              ),
              const SizedBox(height: 13),
              OrnateProgressBar(value: c.todayPercent / 100, color: era.primary),
              const SizedBox(height: 8),
              Text(
                c.activeHabits.isEmpty
                    ? 'Önce vazifelerini belirle, sonra çentik atmaya başla.'
                    : '${c.todayCompleted} / ${c.activeHabits.length} vazife tamamlandı.',
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            const Expanded(child: SectionTitle('Vazifelerim', icon: Icons.edit_note_rounded)),
            OrnateButton(
              label: 'Yeni vazife',
              icon: Icons.add_rounded,
              onPressed: () => openEditor(context),
            ),
          ],
        ),
        const SizedBox(height: 10),
        if (c.activeHabits.isEmpty)
          const RealmCard(child: Text('Henüz vazifen yok. Bir alışkanlık belirleyerek ilk fermanı yaz.')),
        ...c.activeHabits.map(
          (habit) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _HabitTile(
              habit: habit,
              controller: c,
              onEdit: () => openEditor(context, habit),
            ),
          ),
        ),
        const SizedBox(height: 12),
        RealmCard(
          color: const Color(0xFFFFF7E1),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('Planlı İstirahat', icon: Icons.nightlight_round),
              const SizedBox(height: 8),
              const Text('İrade yalnızca yüklenmek değil, doğru vakitte nefes almaktır.'),
              const SizedBox(height: 12),
              OrnateButton(
                label: c.restDates.contains(c.today)
                    ? 'Bugünkü istirahat mührünü kaldır'
                    : 'Bugünü planlı istirahat olarak işaretle',
                icon: c.restDates.contains(c.today) ? Icons.sunny : Icons.bedtime_outlined,
                expanded: true,
                onPressed: c.toggleRestDay,
              ),
              const SizedBox(height: 8),
              const Text(
                'Planlı istirahat günlerinde itibar cezası uygulanmaz.',
                style: TextStyle(fontSize: 11, color: Colors.black54),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        OriginalKingdomArt(sky: era.secondary, land: era.primary, highlight: era.accent, height: 165),
      ],
    );
  }
}

class _HabitTile extends StatelessWidget {
  const _HabitTile({
    required this.habit,
    required this.controller,
    required this.onEdit,
  });

  final Habit habit;
  final RealmController controller;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final era = controller.era;
    final done = habit.completedOn(controller.today);
    return RealmCard(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      child: Row(
        children: [
          InkWell(
            onTap: () => controller.toggleHabit(habit),
            borderRadius: BorderRadius.circular(20),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: done
                      ? [Color.lerp(era.primary, Colors.white, .1)!, era.primary]
                      : [const Color(0xFFFFFCF6), const Color(0xFFF3EBDC)],
                ),
                border: Border.all(color: done ? const Color(0xFFE2C56C) : const Color(0xFFD9CCB4)),
              ),
              child: Icon(done ? Icons.check_rounded : Icons.radio_button_unchecked_rounded, color: done ? Colors.white : era.primary),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: InkWell(
              onTap: () => controller.toggleHabit(habit),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    habit.name,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 15,
                      decoration: done ? TextDecoration.lineThrough : null,
                    ),
                  ),
                  if (habit.description.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 3),
                      child: Text(habit.description, style: const TextStyle(fontSize: 11.5, color: Colors.black54)),
                    ),
                  const SizedBox(height: 7),
                  Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    children: [
                      RealmPill(
                        label: '+${12 + habit.difficulty * 6} XP',
                        icon: Icons.bolt_rounded,
                        color: era.secondary,
                      ),
                      RealmPill(
                        label: ['?', 'Kolay', 'Orta', 'Zorlu'][habit.difficulty],
                        icon: Icons.flag_outlined,
                        color: const Color(0xFFFFE8C7),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          PopupMenuButton<String>(
            tooltip: 'Vazife seçenekleri',
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: Text('Düzenle')),
              PopupMenuItem(value: 'archive', child: Text('Arşivle')),
            ],
            onSelected: (value) {
              if (value == 'edit') onEdit();
              if (value == 'archive') controller.archiveHabit(habit);
            },
          ),
        ],
      ),
    );
  }
}
