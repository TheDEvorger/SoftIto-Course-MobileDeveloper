import 'package:sqlite3/sqlite3.dart';
import '../../../core/database/app_database.dart';
import '../domain/venture.dart';
import '../domain/venture_repository.dart';

class SqliteVentureRepository implements VentureRepository {
  SqliteVentureRepository(this.database);
  final AppDatabase database;

  Venture _decode(Row row) => Venture(
        id: row['id'] as String,
        name: row['name'] as String,
        problem: row['problem'] as String,
        audience: row['audience'] as String,
        createdAt: DateTime.fromMicrosecondsSinceEpoch(row['created_at'] as int),
      );

  @override
  List<Venture> all() => database.db
      .select('SELECT * FROM ventures ORDER BY created_at DESC')
      .map(_decode)
      .toList();

  @override
  Venture? find(String id) {
    final rows = database.db.select(
      'SELECT * FROM ventures WHERE id = ?', [id],
    );
    return rows.isEmpty ? null : _decode(rows.first);
  }

  @override
  void add(Venture venture) => database.db.execute(
        '''INSERT INTO ventures(id,name,problem,audience,created_at)
           VALUES (?,?,?,?,?)''',
        [venture.id, venture.name, venture.problem, venture.audience,
          venture.createdAt.microsecondsSinceEpoch],
      );
}
