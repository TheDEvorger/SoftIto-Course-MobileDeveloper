import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/database/database_provider.dart';
import '../../../core/ids/new_id.dart';
import '../data/sqlite_venture_repository.dart';
import '../domain/venture.dart';
import '../domain/venture_repository.dart';

final ventureRepositoryProvider = Provider<VentureRepository>(
  (ref) => SqliteVentureRepository(ref.watch(databaseProvider)),
);
final venturesProvider = Provider<List<Venture>>(
  (ref) => ref.watch(ventureRepositoryProvider).all(),
);
final ventureProvider = Provider.family<Venture?, String>(
  (ref, id) => ref.watch(ventureRepositoryProvider).find(id),
);
final ventureViewModelProvider = Provider<VentureViewModel>(
  (ref) => VentureViewModel(ref),
);

class VentureViewModel {
  VentureViewModel(this.ref);
  final Ref ref;

  void create({required String name, required String problem,
    required String audience}) {
    final error = Venture.validateName(name);
    if (error != null) throw ArgumentError(error);
    ref.read(ventureRepositoryProvider).add(Venture(
      id: newId(), name: name.trim(), problem: problem.trim(),
      audience: audience.trim(), createdAt: DateTime.now(),
    ));
    ref.invalidate(venturesProvider);
  }
}
