import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../domain/venture.dart';

class VentureTile extends StatelessWidget {
  const VentureTile({required this.venture, super.key});
  final Venture venture;

  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => context.go('/venture/${venture.id}'),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(children: [
          const CircleAvatar(child: Icon(Icons.lightbulb_outline)),
          const SizedBox(width: 14),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(venture.name, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(venture.problem.isEmpty ? 'Problemi henüz tanımlanmadı.'
                  : venture.problem,
                maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
          )),
          const Icon(Icons.arrow_forward_ios, size: 16),
        ]),
      ),
    ),
  );
}
