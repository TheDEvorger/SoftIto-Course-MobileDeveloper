import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'venture_providers.dart';
import 'venture_tile.dart';
import 'create_venture_dialog.dart';

class VentureOverview extends ConsumerWidget {
  const VentureOverview({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ventures = ref.watch(venturesProvider);
    return ListView(padding: const EdgeInsets.all(24), children: [
      ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 850),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Fikirlerini geliştir, kanıtla, büyüt.',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          const Text('Her girişim bir soruyla başlar. MeHEnG, cevabı '
            'hipotezlerle ve gerçek deneylerle bulmana yardımcı olur.'),
          const SizedBox(height: 22),
          FilledButton.icon(
            onPressed: () => showDialog<void>(context: context,
              builder: (_) => const CreateVentureDialog()),
            icon: const Icon(Icons.add),
            label: const Text('Yeni girişim oluştur'),
          ),
          const SizedBox(height: 32),
          Text('Girişimlerin', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          if (ventures.isEmpty)
            const Card(child: Padding(
              padding: EdgeInsets.all(22),
              child: Text('Henüz bir girişim yok. İlk fikrini oluşturarak başla.'),
            ))
          else
            for (final venture in ventures)
              VentureTile(venture: venture),
          const SizedBox(height: 28),
          Text('MeHEnG yolculuğu', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          const Wrap(spacing: 8, runSpacing: 8, children: [
            Chip(label: Text('01 · Keşfet')),
            Chip(label: Text('02 · Doğrula')),
            Chip(label: Text('03 · İnşa et')),
            Chip(label: Text('04 · Büyüt')),
          ]),
        ]),
      ),
    ]);
  }
}
