import 'venture.dart';

abstract class VentureRepository {
  List<Venture> all();
  Venture? find(String id);
  void add(Venture venture);
}
