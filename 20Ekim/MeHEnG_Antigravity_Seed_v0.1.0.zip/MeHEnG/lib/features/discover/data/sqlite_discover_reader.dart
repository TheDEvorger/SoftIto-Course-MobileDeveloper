import '../../../core/database/app_database.dart';
import '../domain/hypothesis.dart';
import '../domain/experiment.dart';
import '../domain/evidence.dart';

class SqliteDiscoverReader {
  SqliteDiscoverReader(this.database);
  final AppDatabase database;

  List<Hypothesis> hypotheses(String id) => database.db
      .select('SELECT * FROM hypotheses WHERE venture_id=? ORDER BY created_at DESC', [id])
      .map((r) => Hypothesis(
        id: r['id'] as String,
        ventureId: r['venture_id'] as String,
        statement: r['statement'] as String,
        createdAt: DateTime.fromMicrosecondsSinceEpoch(r['created_at'] as int),
      )).toList();

  List<Experiment> experiments(String id) => database.db
      .select('SELECT * FROM experiments WHERE hypothesis_id=? ORDER BY created_at DESC', [id])
      .map((r) => Experiment(
        id: r['id'] as String,
        hypothesisId: r['hypothesis_id'] as String,
        title: r['title'] as String,
        method: r['method'] as String,
        createdAt: DateTime.fromMicrosecondsSinceEpoch(r['created_at'] as int),
      )).toList();

  List<Evidence> evidence(String id) => database.db
      .select('SELECT * FROM evidence WHERE experiment_id=? ORDER BY created_at DESC', [id])
      .map((r) => Evidence(
        id: r['id'] as String,
        experimentId: r['experiment_id'] as String,
        note: r['note'] as String,
        direction: EvidenceDirection.values.byName(r['direction'] as String),
        createdAt: DateTime.fromMicrosecondsSinceEpoch(r['created_at'] as int),
      )).toList();
}
