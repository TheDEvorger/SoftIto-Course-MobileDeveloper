class Evidence {
  const Evidence({required this.id, required this.experimentId,
    required this.note, required this.direction, required this.createdAt});
  final String id;
  final String experimentId;
  final String note;
  final EvidenceDirection direction;
  final DateTime createdAt;
}

enum EvidenceDirection { supports, contradicts, neutral }
