import 'package:flutter/material.dart';

abstract final class MehengColors {
  static const forest = Color(0xFF193E38);
  static const canvas = Color(0xFFF5F2EB);
  static const copper = Color(0xFFD57C52);
  static const sage = Color(0xFF9EB8A9);
  static const ink = Color(0xFF263331);
}

abstract final class MehengTheme {
  static final light = ThemeData(
    useMaterial3: true,
    colorScheme: const ColorScheme.light(
      primary: MehengColors.forest,
      onPrimary: Colors.white,
      secondary: MehengColors.copper,
      surface: MehengColors.canvas,
      onSurface: MehengColors.ink,
    ),
    scaffoldBackgroundColor: MehengColors.canvas,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: MehengColors.canvas,
      foregroundColor: MehengColors.ink,
      centerTitle: false,
    ),
  );
}
