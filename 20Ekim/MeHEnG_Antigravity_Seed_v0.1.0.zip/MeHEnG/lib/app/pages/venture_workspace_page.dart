import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/discover/discover.dart';
import '../../features/ventures/ventures.dart';

class VentureWorkspacePage extends ConsumerWidget {
  const VentureWorkspacePage({required this.ventureId, super.key});
  final String ventureId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final venture = ref.watch(ventureProvider(ventureId));
    if (venture == null) {
      return Scaffold(appBar: AppBar(), body: const Center(
        child: Text('Girişim bulunamadı.')));
    }
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back),
          tooltip: 'Ana sayfa', onPressed: () => context.go('/')),
        title: const Text('MeHEnG · Discover'),
      ),
      body: Center(child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 980),
        child: ListView(padding: const EdgeInsets.all(20), children: [
          Text(venture.name, style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          Text('Problem: ${venture.problem.isEmpty ? "Henüz tanımlanmadı" : venture.problem}'),
          const SizedBox(height: 8),
          Text('Hedef kitle: ${venture.audience.isEmpty ? "Henüz tanımlanmadı" : venture.audience}'),
          const SizedBox(height: 24),
          HypothesesSection(ventureId: ventureId),
        ]),
      )),
    );
  }
}
