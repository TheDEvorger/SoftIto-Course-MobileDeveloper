import 'package:flutter/material.dart';
import 'routing/app_router.dart';
import 'theme/meheng_theme.dart';

class MehengApp extends StatelessWidget {
  const MehengApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp.router(
        title: 'MeHEnG',
        debugShowCheckedModeBanner: false,
        theme: MehengTheme.light,
        routerConfig: appRouter,
      );
}
