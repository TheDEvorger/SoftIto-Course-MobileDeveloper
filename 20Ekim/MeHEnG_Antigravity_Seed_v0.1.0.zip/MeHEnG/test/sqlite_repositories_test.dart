import 'package:flutter_test/flutter_test.dart';
import 'package:meheng/core/database/app_database.dart';
import 'package:meheng/features/ventures/data/sqlite_venture_repository.dart';
import 'package:meheng/features/ventures/domain/venture.dart';
import 'package:meheng/features/discover/data/sqlite_discover_repository.dart';
import 'package:meheng/features/discover/domain/hypothesis.dart';
import 'package:meheng/features/discover/domain/experiment.dart';
import 'package:meheng/features/discover/domain/evidence.dart';

void main() {
  test('private venture and evidence chain persist in SQLite', () {
    final db = AppDatabase.inMemory();
    addTearDown(db.dispose);
    final ventures = SqliteVentureRepository(db);
    final discover = SqliteDiscoverRepository(db);
    final now = DateTime.now();
    ventures.add(Venture(id: 'v1', name: 'Test girişimi',
      problem: 'Bir problem', audience: 'Müşteri', createdAt: now));
    discover.addHypothesis(Hypothesis(id: 'h1', ventureId: 'v1',
      statement: 'İnsanlar buna ödeme yapar', createdAt: now));
    discover.addExperiment(Experiment(id: 'x1', hypothesisId: 'h1',
      title: 'Görüşme', method: '10 müşteri ile konuş', createdAt: now));
    discover.addEvidence(Evidence(id: 'e1', experimentId: 'x1',
      note: 'İlk müşteri kabul etmedi.',
      direction: EvidenceDirection.contradicts, createdAt: now));
    expect(ventures.all().single.name, 'Test girişimi');
    expect(discover.hypotheses('v1').single.id, 'h1');
    expect(discover.experiments('h1').single.id, 'x1');
    expect(discover.evidence('x1').single.direction,
      EvidenceDirection.contradicts);
    expect(db.db.select('PRAGMA user_version').first.values.first, 1);
  });

  test('SQLite enforces foreign key constraints', () {
    final db = AppDatabase.inMemory();
    addTearDown(db.dispose);
    expect(() => SqliteDiscoverRepository(db).addHypothesis(
      Hypothesis(id: 'bad', ventureId: 'missing', statement: 'X',
        createdAt: DateTime.now())), throwsException);
  });
}
