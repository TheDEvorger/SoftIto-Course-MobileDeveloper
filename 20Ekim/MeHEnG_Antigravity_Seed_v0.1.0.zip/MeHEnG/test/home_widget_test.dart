import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:meheng/app/meheng_app.dart';
import 'package:meheng/features/ventures/domain/venture.dart';
import 'package:meheng/features/ventures/domain/venture_repository.dart';
import 'package:meheng/features/ventures/presentation/venture_providers.dart';

class EmptyVentureRepository implements VentureRepository {
  @override
  List<Venture> all() => [];
  @override
  Venture? find(String id) => null;
  @override
  void add(Venture venture) {}
}

void main() {
  testWidgets('home opens and shows venture empty state', (tester) async {
    await tester.pumpWidget(ProviderScope(
      overrides: [ventureRepositoryProvider.overrideWithValue(
        EmptyVentureRepository())],
      child: const MehengApp(),
    ));
    await tester.pumpAndSettle();
    expect(find.text('MeHEnG'), findsOneWidget);
    expect(find.textContaining('Henüz bir girişim yok'), findsOneWidget);
    expect(find.byIcon(Icons.dashboard), findsWidgets);
  });
}
